/**
 * SETTINGS.JS
 * Preferensi tampilan yang disimpan lokal (localStorage), independen dari
 * akun/login — bukan bagian dari payload data OEE.
 */
const Settings = (() => {
  'use strict';

  const KEY_DECOR = 'fima_decor_enabled';
  const KEY_THEME = 'fima_theme';
  const KEY_LOGIN_THEME = 'fima_login_theme';

  const isDecorEnabled = () => localStorage.getItem(KEY_DECOR) === '1';

  const setDecorEnabled = (on) => {
    localStorage.setItem(KEY_DECOR, on ? '1' : '0');
  };

  const getTheme = () => {
    try {
      const stored = localStorage.getItem(KEY_THEME);
      if (stored) return stored;
    } catch (e) { /* private mode / blocked storage */ }
    // Preferensi sistem sebagai default awal jika pengguna belum memilih
    try {
      if (typeof matchMedia === 'function' && matchMedia('(prefers-color-scheme: dark)').matches) {
        return 'dark';
      }
    } catch (e) {}
    return 'light';
  };

  const applyTheme = (mode) => {
    document.documentElement.setAttribute('data-theme', mode);
    // Sinkronkan pill Mode Tampilan di sidebar
    document.querySelectorAll('[data-color-mode]').forEach(btn => {
      const isDark = mode === 'dark';
      btn.classList.toggle('on', isDark ? btn.dataset.colorMode === 'dark' : btn.dataset.colorMode === 'light');
    });
  };

  const setTheme = (mode) => {
    try { localStorage.setItem(KEY_THEME, mode); } catch (e) {}
    applyTheme(mode);
  };

  const toggleTheme = () => {
    let next;
    if (getTheme() === 'dark') {
      // Kembali ke style terang terakhir (Standar/Profesional)
      try {
        const style = localStorage.getItem('fima_app_style') || 'light';
        next = style === 'professional' ? 'professional' : 'light';
      } catch(e) { next = 'light'; }
    } else {
      next = 'dark';
    }
    setTheme(next);
    return next;
  };

  /* =========================
     LOGIN THEME
     'santai' | 'professional'
     ========================= */
  const normalizeLoginTheme = (mode) =>
    mode === 'professional' ? 'professional' : 'santai';

  const getLoginTheme = () =>
    normalizeLoginTheme(localStorage.getItem(KEY_LOGIN_THEME) || 'santai');

  const applyLoginTheme = (mode) => {
    const theme = normalizeLoginTheme(mode);
    const overlay = document.getElementById('loginOverlay');
    if (!overlay) return theme;

    overlay.classList.toggle('login-theme-santai', theme === 'santai');
    overlay.classList.toggle('login-theme-professional', theme === 'professional');
    return theme;
  };

  const setLoginTheme = (mode) => {
    const theme = normalizeLoginTheme(mode);
    localStorage.setItem(KEY_LOGIN_THEME, theme);
    applyLoginTheme(theme);
    return theme;
  };

  const toggleLoginTheme = () => {
    const next = getLoginTheme() === 'professional' ? 'santai' : 'professional';
    return setLoginTheme(next);
  };

  /*
   * Sinkronisasi tema aplikasi dengan tema yang dipakai saat login.
   * Jika user masuk menggunakan Login Profesional, aplikasi langsung
   * memakai tema Profesional tanpa perlu memilih tema lagi di dalam aplikasi.
   */
  const syncAppThemeWithLoginTheme = () => {
    const appTheme = getLoginTheme() === 'professional' ? 'professional' : 'light';
    setTheme(appTheme);
    return appTheme;
  };

  // Terapkan tema aplikasi tersimpan.
  applyTheme(getTheme());

  // Terapkan tema login setelah elemen overlay tersedia.
  document.addEventListener('DOMContentLoaded', () => {
    applyLoginTheme(getLoginTheme());

    const overlay = document.getElementById('loginOverlay');
    if (overlay) {
      overlay.classList.toggle('decor-on', isDecorEnabled());
    }
  });

  return {
    isDecorEnabled,
    setDecorEnabled,
    getTheme,
    setTheme,
    toggleTheme,
    getLoginTheme,
    setLoginTheme,
    toggleLoginTheme,
    syncAppThemeWithLoginTheme
  };
})();

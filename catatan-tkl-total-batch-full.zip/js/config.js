/**
 * CONFIG.JS
 * Semua konstanta & konfigurasi aplikasi terpusat di sini.
 * Untuk ubah nilai (PIN, target OEE, URL server), cukup edit file ini.
 */
const CONFIG = Object.freeze({
  // ====== SUPABASE ======
  // Project: rximlgklzghbtgyqvmux
  SUPABASE_URL:      'https://rximlgklzghbtgyqvmux.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ4aW1sZ2tsemdoYnRneXF2bXV4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY0MjYyMDcsImV4cCI6MjEwMjAwMjIwN30.igM5-0JRWQSb6zAlN9qN2MvuG4A5UGuIL3OpVX1nFMo',

  // Nama tabel Supabase tempat data OEE disimpan (lihat supabase-setup.sql)
  DB_TABLE: 'oee_data',
  DB_SPEED_STANDAR_TABLE: 'speed_standar',
  SCHEMA_VERSION: 1,

  // ====== AUTENTIKASI ======
  // 'supabase' = login email/password via Supabase Auth (rekomendasi)
  // 'pin'      = login PIN lama (fallback, tidak butuh internet/Supabase)
  AUTH_MODE:   'supabase',
  CORRECT_PIN: '2026',
  AUTH_KEY:    'fima_oee_logged_in',

  // ====== STORAGE ======
  DB_KEY:      'fima_oee_db_v3',
  NAV_MODE_KEY: 'fima_nav_mode',
  EVAL_SHIFT_KEY: 'fima_eval_shift',
  TOOLBAR_COLLAPSED_KEY: 'fima_toolbar_collapsed',
  ACTIVE_SCREEN_KEY: 'fima_active_screen',
  COL_PRESET_KEY: 'fima_col_preset',
  WIZARD_SEEN_KEY: 'fima_wizard_seen',
  DEFAULT_WO_KEY: 'fima_default_wo',
  COL_TOGGLE_OPEN_KEY: 'fima_col_toggle_open',
  VIEW_MODE_KEY: 'fima_view_mode',

  // Auto-save LOKAL (localStorage) setiap N ms. Tidak menyentuh Supabase —
  // hanya menjaga-jaga data tidak hilang kalau browser/tab tertutup tiba-tiba.
  AUTO_SAVE_INTERVAL_MS: 10000, // 10 detik

  // Auto-save ke Supabase setiap N ms (senyap, tanpa tombol Simpan).
  // Hanya jalan saat online + login cloud; skip jika offline / Mode Offline.
  // Interval lebih jarang dari lokal (10 dtk lokal, 30 dtk cloud) agar tidak membebani jaringan.
  AUTO_SAVE_SUPABASE_INTERVAL_MS: 30000, // 30 detik

  // ====== DEFAULTS ======
  // Jumlah baris awal saat sheet kosong. Viewport tabel menampilkan ~10 baris;
  // baris 11–25 (dan tambahan) digulir di dalam .tbl-wrap.
  DEFAULT_ROWS: 25,

  // ====== SHIFT (menit) ======
  // S1=510, S2=480, S3=450
  SHIFT_A: [510, 480, 450],
  SHIFT_LABELS: ['S1', 'S2', 'S3'],

  // ====== RENTANG SHIFT (dalam menit dari 00:00) ======
  // S1: 07:00 (420) - 15:30 (930)
  // S2: 15:30 (930) - 23:30 (1410)
  // S3: 23:30 (1410) - 07:00 (420) — lintas tengah malam
  SHIFT_RANGES: [
    { from: 420,  to: 930,  index: 0 }, // S1
    { from: 930,  to: 1410, index: 1 }, // S2
    { from: 1410, to: 1440, index: 2 }, // S3 (sebelum tengah malam)
    { from: 0,    to: 420,  index: 2 }, // S3 (setelah tengah malam)
  ],

  // ====== KODE LOG SHEET (hanya 1–9 yang valid) ======
  // 2           → Produksi / produktif (hijau)
  // 5, 6, 7, 8  → Planned Down Time (amber)
  // 1, 3, 4, 9  → Unplanned Down Time (merah)
  // selain 1–9 → tidak valid, tidak dihitung
  PLANNED_CODES:   new Set([5, 6, 7, 8]),
  UNPLANNED_CODES: new Set([1, 3, 4, 9]),
  PROD_CODES:      new Set([2]),
  VALID_CODES:     new Set([1, 2, 3, 4, 5, 6, 7, 8, 9]),

  // ====== TARGET OEE ======
  TARGET: {
    AVAILABILITY: 90,     // %
    PERFORMANCE:  98,     // %
    QUALITY:      99.50,  // %
    OEE:          88,     // %
    OEE365:       55,     // % ← DIUBAH: target khusus OEE 365 (badge toolbar & health bar)
  },

  // ====== URUTAN KOLOM NAVIGASI (tab order) ======
  // 'durasi' hanya terlihat/terpakai pada Mode Cepat 1 & Mode Cepat 2
  // (disembunyikan otomatis di Mode Normal, tidak ikut tab order berkat
  // filter offsetParent di Navigation.navCells).
  NAV_FIELDS: [
    'kode', 'op', 'mulai', 'panggil', 'teknik', 'selesai', 'durasi',
    'kegiatan', 'masalah', 'ms', 'disposisi', 'description', 'wo', 'batch',
    'good', 'defect'
  ],

  // ====== LABEL KOLOM (untuk indikator posisi) ======
  FIELD_LABELS: {
    kode: 'KODE', op: 'MAN POWER', ms: 'FREKUENSI MINOR STOP (x)', mulai: 'JAM MULAI', panggil: 'PANGGIL TEKNIK',
    teknik: 'TEKNIK DATANG', selesai: 'JAM SELESAI', durasi: 'DURASI (MENIT)',
    kegiatan: 'KEGIATAN',
    masalah: 'MASALAH', disposisi: 'DISPOSISI', description: 'DESCRIPTION',
    wo: 'NOMOR WO',
    batch: 'PRODUK & BATCH', good: 'GOOD', defect: 'DEFECT'
  },

  // ====== RATE KEMAS L1 / L2 (bag per menit) by man power ======
  // L1: OP < 3 → 8; OP ≥ 3 → 12 (batas mesin)
  // L2: by ukuran ml + OP band
  KEMAS_L1_RATE: { low: 8, high: 12, opThreshold: 3 },
  KEMAS_L2_RATE: {
    100: { le3: 14, gt3: 18 },
    250: { le3: 10, gt3: 14 },
    500: { le3: 8,  gt3: 12 },
  },

  // ====== SUGESTI KEGIATAN (ghost-text) ======
  // Muncul otomatis saat mengetik di kolom Kegiatan (sel tabel, Isi Massal,
  // maupun Form Input), disesuaikan dengan Tahapan Proses yang aktif
  // (dropdown "Tahapan" di Data & Penyimpanan). Silakan tambah/ubah daftar
  // di bawah ini sesuka hati — tidak perlu ubah kode JS lain.
  // 'common' = selalu ikut disertakan di tahapan manapun.
  KEGIATAN_SUGGESTIONS: {
    mixing: [
      'Loading Lot A', 'Loading Lot B', 'Loading Lot C', 'Loading Lot D',
      'Mixing', 'Persiapan', 'Ganti Lot', 'Ganti Baju',
      'Merapihkan Media', 'Papar Media', 'Tutup Media', 'Ganti SP Media',
    ],
    filling: [
      'Filling Lot A', 'Filling Lot B', 'Filling Lot C', 'Filling Lot D',
      'Persiapan',
      'Merapihkan Media', 'Papar Media', 'Tutup Media', 'Ganti SP Media',
    ],
    steril: [
      'Sterilisasi', 'Persiapan', 'Loading Chamber', 'Unloading Chamber',
    ],
    visual: [
      'Inspeksi Visual', 'Persiapan', 'Sortir Reject',
    ],
    kemas: [
      'Pengemasan Sekunder', 'Persiapan', 'Ganti Batch', 'Labeling',
    ],
    common: [
      'Cleaning', 'Istirahat', 'Menunggu Instruksi',
      'Merapihkan Media', 'Papar Media', 'Tutup Media', 'Ganti SP Media',
    ],
  },

  // ====== STANDARISASI KOSA KATA (Issue #9) ======
  // Alias (tulisan bervariasi) → bentuk baku.
  // Saat user mengetik alias lalu blur / pilih, teks diganti ke bentuk baku.
  // Key & value dibandingkan case-insensitive; value yang disimpan = penulisan baku.
  // Tambah baris di sini untuk kegiatan lain yang sering ditulis berbeda-beda.
  KEGIATAN_ALIASES: {
    // Merapihkan Media
    'merapihkan media': 'Merapihkan Media',
    'rapihkan media': 'Merapihkan Media',
    'beberes media': 'Merapihkan Media',
    'beres media': 'Merapihkan Media',
    'bungkus media': 'Merapihkan Media',
    'rapihin media': 'Merapihkan Media',
    'merapikan media': 'Merapihkan Media',
    'rapi media': 'Merapihkan Media',
    // Papar Media
    'papar media': 'Papar Media',
    'memapar media': 'Papar Media',
    'buka media': 'Papar Media',
    // Tutup Media
    'tutup media': 'Tutup Media',
    'menutup media': 'Tutup Media',
    'nutup media': 'Tutup Media',
    // Ganti SP Media
    'ganti sp media': 'Ganti SP Media',
    'ganti sp': 'Ganti SP Media',
    'ganti media': 'Ganti SP Media',
    'ganti sampel media': 'Ganti SP Media',
  },

  // ====== KODE PRODUK REFERENSI (autocomplete nama produk) ======
  // Filter prefix saat mengetik di kolom Nama Produk. Klik pilihan → isi kode,
  // kursor di akhir supaya bisa lanjut ketik bebas (mis. "VTTS1 L030001").
  // visual & kemas memakai sufiks huruf; tahapan lain (mixing/filling/steril)
  // memakai sufiks angka. Silakan tambah/ubah daftar di sini — tidak perlu
  // sentuh js/suggest.js.
  PRODUCT_CODE_SUGGESTIONS: {
mixing: ['VTTS1 Mixing L', 'VTTS1 Loading L', 'VKAM1 Mixing L', 'VKAM1 Loading L', 'VLON1 Mixing L', 'VLON1 Loading L', 'VMON1 Mixing L', 'VMON1 Loading L', 'VTRA1 Mixing L', 'VTRA1 Loading L', 'VCLN2 Mixing L', 'VCLN2 Loading L', 'VMNT1 Mixing L', 'VMNT1 Loading L', 'VTRM1 Mixing L', 'VTRM1 Loading L', 'VPEL1 Mixing L', 'VPEL1 Loading L', 'ITTC2 Mixing L', 'ITTC2 Loading L', 'VTTC1 Mixing L', 'VTTC1 Loading L'],
    filling: ['VTTS1','VKAM1','VLON1','VMON1','VTRA1','VCLN2','VMNT1','VTRM1','VPEL1','ITTC2','VTTC1'],
    steril:  ['VTTS1','VKAM1','VLON1','VMON1','VTRA1','VCLN2','VMNT1','VTRM1','VPEL1','ITTC2','VTTC1'],
    visual:  ['VTTSA','VKAMA','VLONA','VMONA','VTRAB','VCLNB','VMNTA','VTRME','VPELA','ITTCB','VTTCA'],
    kemas:   ['VTTSA','VKAMA','VLONA','VMONA','VTRAB','VCLNB','VMNTA','VTRME','VPELA','ITTCB','VTTCA'],
  },

  // ====== NAMA MESIN (auto-isi sesuai Tahapan + Line) ======
  // Dipakai oleh UI.fillMachineName() untuk mengisi field "Nama Mesin"
  // (#fMesinNama di Data & Penyimpanan, dicerminkan juga di header Log Sheet)
  // secara otomatis begitu Line / Tahapan Proses diganti.
  // Key = '<tahapan>|<line>' (huruf kecil). Silakan tambah/ubah daftar di
  // sini sesuka hati — tidak perlu sentuh js/ui.js.
    MACHINE_NAMES: {
    'mixing|1':  'Mixing Tank OLSA PCBS 2500',
    'filling|1': 'Automatic Form Fill Seal Machine Shinva RSYG2-1-23005',
    'steril|1':  'Autoclave Getinge 2',
    'visual|1':  'Mesin Bonfiglioli',
    'kemas|1':   'Overwrapping Machine Sysflex Line 1',

    'mixing|2':  'Mixing Tank Tofflon APLS 3500',
    'filling|2': 'Automatic Form Fill Seal Machine Plumat FFS 991',
    'steril|2':  'Autoclave Shinva',
    'visual|2':  'NIKKA DENSOK',
    'kemas|2':   'Overwrapping Machine Sysflex Line 2',

    'mixing|4':  'Mixing TANK LB4000/1',
    'filling|4': 'Automatic Form Fill Seal Machine Plumat FFS 892',
    'steril|4':  'Autoclave Getinge 4',
    'visual|4':  'NIKKA DENSOK',
    'kemas|4':   'Overwrapping Machine Plumat OW 834',
  },

  // Pilihan ganda untuk kombinasi tertentu (urutan pertama = default)
  MACHINE_NAMES_ALT: {
    'kemas|1': ['Overwrapping Machine Sysflex Line 1', 'Mesin Colimatic'],
  },

  // ====== MODE INPUT (Normal / Cepat 1 / Cepat 2) ======
  INPUT_MODE_KEY: 'fima_input_mode',

  // Jam mulai standar per shift, dipakai untuk dropdown cepat pada baris pertama
  // di Mode Cepat 1 & Mode Cepat 2 (lihat js/quickmode.js).
  SHIFT_START_TIMES: ['07:00', '15:30', '23:30'],

  // ====== BULAN (untuk format tanggal) ======
  MONTHS: ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'],

  // ====== CUACA & EFEK VISUAL ======
  // Koordinat pabrik untuk fetch cuaca dari Open-Meteo (gratis, tanpa API key)
  // ⚠ Ubah ke koordinat pabrik Anda sendiri untuk akurasi maksimal.
  LOCATION: {
    lat: -6.9147,       // contoh: Bandung
    lon: 107.6098,
    label: 'Bandung'
  },
  WEATHER_REFRESH_MIN: 30,      // refresh API tiap N menit
  SNOW_MONTHS: [12],            // bulan dengan efek salju dekoratif (1=Jan..12=Des)
  AUTUMN_MONTHS: [9, 10, 11],   // bulan dengan efek daun berguguran (state musim gugur dekoratif)
  RAINBOW_RECENT_MIN: 90,       // menit setelah hujan → pelangi muncul

  // Tanggal khusus yang memicu kembang api di background login
  SPECIAL_DATES: [
    { month: 1,  day: 1,  name: 'Tahun Baru' },
    { month: 8,  day: 17, name: 'HUT RI' },
    { month: 12, day: 31, name: 'Malam Tahun Baru' }
  ],

  // ====== SCENE SCHEDULE (tema background login berdasarkan waktu) ======
  // Jam dalam menit dari 00:00. Edit rentang ini untuk mengubah kapan tema berganti.
  SCENE_SCHEDULE: [
    { from: 0,    to: 240,  name: 'night'   }, // 00:00 - 04:00
    { from: 240,  to: 420,  name: 'sunrise' }, // 04:00 - 07:00  (fajar)
    { from: 420,  to: 960,  name: 'day'     }, // 07:00 - 16:00  (siang)
    { from: 960,  to: 1080, name: 'sunset'  }, // 16:00 - 18:00  (senja)
    { from: 1080, to: 1440, name: 'night'   }, // 18:00 - 24:00  (malam)
  ],
});
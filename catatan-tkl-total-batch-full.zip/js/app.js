/**
 * APP.JS
 * Entry point aplikasi. Menginisialisasi session, binding event, dan boot modul lain.
 */
const App = (() => {
  'use strict';

  /**
   * Inisialisasi aplikasi utama (setelah login berhasil).
   */
  const startMain = () => {
    // Load state dari localStorage
    UI.loadNavMode();
    UI.loadEvalShift();

    // Apply UI awal
    UI.applyModeUI();
    UI.applyShiftUI();
    UI.loadToolbarCollapsed();
    UI.loadActiveScreen();
    UI.loadColToggleState();
    UI.loadViewMode();
    Rows.updateMatrixProductHeaders();

    // Set default tanggal = hari ini
    State.el.fDate.value = Utils.todayLocal();
    UI.updateShiftIndicator();

    // Load record pertama
    Storage.loadRecord();

    // Auto-save LOKAL tiap N ms (default 10 dtk) — tidak menyentuh Supabase
    // Auto-save SUPABASE tiap M ms (default 30 dtk) — hanya saat online
    // (lewat Perf.every supaya ikut berhenti saat app disembunyikan/background)
    if (typeof Perf !== 'undefined') {
      Perf.every(CONFIG.AUTO_SAVE_INTERVAL_MS || 10000, Storage.autoSaveLocal);
      Perf.every(CONFIG.AUTO_SAVE_SUPABASE_INTERVAL_MS || 30000, Storage.autoSaveSupabase);
    } else {
      setInterval(Storage.autoSaveLocal, CONFIG.AUTO_SAVE_INTERVAL_MS || 10000);
      setInterval(() => { Storage.autoSaveSupabase(); }, CONFIG.AUTO_SAVE_SUPABASE_INTERVAL_MS || 30000);
    }

    // Start clock
    UI.startClock();

    // Setup PWA & Service Worker
    UI.setupPWA();
    UI.registerServiceWorker();

    // Dashboard (rekap data & grafik) — bind sekali saat app utama siap
    if (typeof Dashboard !== 'undefined') Dashboard.init();

    // Wizard Setup Awal — HANYA di-init setelah login berhasil, supaya
    // auto-open pertama kali tidak menimpa layar login.
    if (typeof Wizard !== 'undefined') Wizard.init();
  };

  /**
   * Binding semua event listeners utama (dipanggil sekali di DOMContentLoaded).
   */
  const bindEvents = () => {
    // Login
    // Dipasang di bindEvents setelah seluruh elemen DOM tersedia.
    if (State.el.loginForm && typeof Auth !== 'undefined') {
      // Satu handler submit untuk kedua tema; tema hanya mengubah tampilan.
      State.el.loginForm.addEventListener('submit', Auth.handleLogin);
    }
    if (State.el.loginOfflineBtn && typeof Auth !== 'undefined' && Auth.handleOfflineMode) {
      State.el.loginOfflineBtn.addEventListener('click', Auth.handleOfflineMode);
    }
    State.el.btnLogout.addEventListener('click', Auth.handleLogout);

    // Shift & Mode
    UI.bindModeButtons();
    UI.bindShiftButtons();
    UI.bindUnifiedControls();
    UI.bindToolbarToggle();
    UI.bindScreenNav();
    UI.bindLogsheetHelp();
    UI.bindColToggleCollapse();
    UI.bindViewModeToggle();

    // Keyboard navigation
    Navigation.bindKeyboard();
    Navigation.bindFocusin();
    Navigation.bindColumnToggles();
    Navigation.bindColumnPresets();
    Navigation.loadColumnPreset();
    if (State.el.oeeIndicator) {
      State.el.oeeIndicator.addEventListener('click', () => UI.showScreen('oee'));
    }
    if (State.el.oee365Indicator) {
      State.el.oee365Indicator.addEventListener('click', () => UI.showScreen('oee365'));
    }
    const btnMeeting = document.getElementById('btnDashboardMeeting');
    if (btnMeeting) {
      btnMeeting.addEventListener('click', () => {
        if (typeof UI !== 'undefined' && UI.showScreen) UI.showScreen('weekly');
        else if (typeof WeeklyDashboard !== 'undefined' && WeeklyDashboard.open) WeeklyDashboard.open();
      });
    }

    // ============================================================
    // ROW INTERACTIONS (delegation pada tbody)
    // ============================================================
    State.el.tbody.addEventListener('input', (e) => {
      const t = e.target;

      // Auto-resize textarea
      if (t.tagName === 'TEXTAREA' && ['kegiatan','masalah','disposisi','wo'].includes(t.getAttribute('data-f'))) {
        UI.autoResizeTextarea(t);
      }

      // Kode: strip non-digit
      if (t.getAttribute('data-f') === 'kode') {
        t.value = t.value.replace(/\D/g, '');
        Rows.applyCat(t.closest('tr'));
      }

      // Jam mulai → auto-copy ke jam selesai baris sebelumnya
      if (t.getAttribute('data-f') === 'mulai') {
        const tr = t.closest('tr');
        let prev = tr ? tr.previousElementSibling : null;
        while (prev && !prev.classList.contains('log-row')) prev = prev.previousElementSibling;
        if (prev) {
          const sv = prev.querySelector('[data-f="selesai"]');
          if (sv) {
            sv.value = t.value;
            sv.classList.remove('invalid');
            Navigation.flash(sv);
            Calculation.validateTimeInput(sv);
          }
        }
      }

      // Masking jam
      if (t.classList.contains('t-time')) {
        const v = Utils.maskTime(t.value);
        if (v !== t.value) t.value = v;
        t.classList.remove('invalid');
        Calculation.validateTimeInput(t);
      }

      // Durasi manual: sinkron rantai mulai → durasi → selesai → mulai baris berikutnya.
      // Kosongkan durasi → kosongkan selesai baris ini + mulai baris berikutnya
      // (Issue #5: durasi harus bisa dihapus, tidak langsung terisi ulang).
      if (t.getAttribute('data-f') === 'durasi') {
        const cleaned = t.value.replace(/[^\d.,]/g, '');
        if (cleaned !== t.value) t.value = cleaned;
        const tr = t.closest('tr');
        if (tr) {
          const mulaiEl = tr.querySelector('[data-f="mulai"]');
          const selesaiEl = tr.querySelector('[data-f="selesai"]');
          const mulaiMin = mulaiEl ? Utils.parseTime(mulaiEl.value) : null;
          const raw = String(t.value).trim();
          const durMin = parseFloat(raw.replace(',', '.'));

          let next = tr.nextElementSibling;
          while (next && !next.classList.contains('log-row')) next = next.nextElementSibling;
          const nextMulaiEl = next ? next.querySelector('[data-f="mulai"]') : null;

          if (raw === '' || !isFinite(durMin)) {
            // Durasi dikosongkan → lepas rantai waktu
            if (selesaiEl) {
              selesaiEl.value = '';
              selesaiEl.classList.remove('invalid', 'warn-shift');
            }
            if (nextMulaiEl) {
              nextMulaiEl.value = '';
              nextMulaiEl.classList.remove('invalid', 'warn-shift');
            }
          } else if (mulaiMin != null && durMin >= 0 && selesaiEl) {
            const endStr = Utils.minutesToHHMM(mulaiMin + durMin);
            selesaiEl.value = endStr;
            selesaiEl.classList.remove('invalid');
            Calculation.validateTimeInput(selesaiEl);
            // Isi mulai baris berikutnya agar rantai antar-baris tetap sinkron
            if (nextMulaiEl) {
              nextMulaiEl.value = endStr;
              nextMulaiEl.classList.remove('invalid');
              Calculation.validateTimeInput(nextMulaiEl);
            }
          }
        }
      }

      Calculation.recalc();
    });

    // ============================================================
    // EVENT CHANGE (Batch & Kode)
    // ============================================================
    State.el.tbody.addEventListener('change', (e) => {
      if (e.target.getAttribute('data-f') === 'batch') {
        const tr = e.target.closest('tr');
        const productName = e.target.value;
        // Update WO untuk baris ini (dari Master Produk)
        Rows.applyWoFromBatch(tr);
        // Cascade produk + WO ke baris bawah
        if (productName) {
          Rows.cascadeProductToBelow(tr, productName);
        }
        Calculation.recalc();
      }
      if (e.target.getAttribute('data-f') === 'kode') {
        Rows.applyCat(e.target.closest('tr'));
        Rows.applyWoFromBatch(e.target.closest('tr'));
      }
    });
    // Juga tangkap input (beberapa browser/select custom)
    State.el.tbody.addEventListener('input', (e) => {
      if (e.target.getAttribute('data-f') === 'batch') {
        Rows.applyWoFromBatch(e.target.closest('tr'));
      }
      if (['good', 'defect'].includes(e.target.getAttribute('data-f'))) {
        e.target.classList.remove('invalid');
        e.target.title = 'Bisa hitung rumus, contoh =10+10+15';
      }
      // Kolom OP: angka saja, 1 digit per baris.
      // Ketik "234" → baris ini=2, baris berikutnya=3, dst.
      if (e.target.getAttribute('data-f') === 'op') {
        const raw = (e.target.value || '').replace(/\D/g, '');
        if (!raw) { e.target.value = ''; return; }
        const tr = e.target.closest('tr');
        const allRows = Rows.rows();
        const startIdx = allRows.indexOf(tr);
        if (startIdx < 0) { e.target.value = raw.slice(0, 1); return; }
        for (let i = 0; i < raw.length; i++) {
          const row = allRows[startIdx + i];
          if (!row) break;
          const opEl = row.querySelector('[data-f="op"]');
          if (opEl) opEl.value = raw[i];
        }
        e.target.value = raw[0];
        // Fokus ke baris terakhir yang terisi (atau baris berikutnya kosong)
        const lastIdx = Math.min(startIdx + raw.length - 1, allRows.length - 1);
        const focusRow = allRows[lastIdx];
        const focusEl = focusRow && focusRow.querySelector('[data-f="op"]');
        if (focusEl && focusEl !== e.target && raw.length > 1) {
          focusEl.focus();
          focusEl.select();
        }
      }
    });

    // Inisial Operator (#op1..#op6): max 3 per kolom, overflow ke kolom berikutnya
    // Contoh: ketik "koko" di OP1 → OP1="KOK", OP2="O"
    const bindOperatorOverflow = () => {
      for (let i = 1; i <= 6; i++) {
        const el = State.el['op' + i] || document.getElementById('op' + i);
        if (!el || el.dataset.opOverflowBound === '1') continue;
        el.dataset.opOverflowBound = '1';
        // Izinkan ketik lebih dari 3 sementara agar overflow terdeteksi
        el.removeAttribute('maxlength');
        el.addEventListener('input', () => {
          let cleaned = (el.value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
          if (cleaned.length <= 3) {
            el.value = cleaned;
            return;
          }
          // Sebar ke op i, i+1, ...
          let pos = i;
          let rest = cleaned;
          while (rest.length > 0 && pos <= 6) {
            const target = State.el['op' + pos] || document.getElementById('op' + pos);
            if (!target) break;
            target.value = rest.slice(0, 3);
            rest = rest.slice(3);
            pos++;
          }
          // Fokus ke kolom terakhir yang diisi
          const last = Math.min(pos - 1, 6);
          const focusEl = State.el['op' + last] || document.getElementById('op' + last);
          if (focusEl) { focusEl.focus(); focusEl.select(); }
        });
      }
    };
    bindOperatorOverflow();

    // ============================================================
    // FOCUSOUT (validasi waktu)
    // ============================================================
    State.el.tbody.addEventListener('focusout', (e) => {
      const t = e.target;
      const field = t.getAttribute('data-f');
      if (field === 'good' || field === 'defect') {
        const raw = t.value.trim();
        const result = Utils.parseArithmeticExpression(raw);
        if (raw && result === null) {
          t.classList.add('invalid');
          t.title = 'Rumus tidak valid. Gunakan angka dan operator +, -, *, /, tanda kurung.';
        } else {
          t.classList.remove('invalid');
          t.removeAttribute('title');
          if (raw) t.value = String(result);
        }
        Calculation.recalc();
      }
      if (t.classList && t.classList.contains('t-time')) {
        const n = Utils.normTime(t.value);
        if (t.value.trim() !== '' && n === null) t.classList.add('invalid');
        else { t.value = n; t.classList.remove('invalid'); }
        Calculation.validateTimeInput(t);
        Calculation.recalc();
      }
    });

    // ============================================================
    // PASTE multi-baris: Jam Mulai & Durasi
    // Mulai:  1745 / 1940.918.4  → jam [. good [. defect]]
    // Durasi: 10 / 35.918.4     → durasi [. good [. defect]]
    // Titik (.) = pemisah
    // ============================================================
    const parseMulaiPasteLine = (line) => {
      const raw = String(line || '').trim();
      if (!raw) return null;

      const parts = raw.split(/[.\t,]/).map(s => s.trim());
      const timeRaw = (parts[0] || '').replace(/\s/g, '');
      const goodRaw = parts.length > 1 ? parts[1].replace(/[^\d]/g, '') : '';
      const defectRaw = parts.length > 2 ? parts[2].replace(/[^\d]/g, '') : '';

      let digits = timeRaw.replace(/\D/g, '');
      let mulai = '';
      if (/^\d{1,2}:\d{1,2}$/.test(timeRaw)) {
        const norm = Utils.normTime(timeRaw);
        mulai = norm || Utils.maskTime(timeRaw);
      } else if (digits.length >= 3 && digits.length <= 4) {
        digits = digits.padStart(4, '0');
        mulai = digits.slice(0, 2) + ':' + digits.slice(2);
        const norm = Utils.normTime(mulai);
        if (norm) mulai = norm;
      } else if (digits.length > 0 && digits.length <= 2) {
        mulai = Utils.normTime(digits) || (digits.padStart(2, '0') + ':00');
      } else {
        return null;
      }

      return {
        mulai,
        good: goodRaw !== '' ? goodRaw : null,
        defect: defectRaw !== '' ? defectRaw : null,
      };
    };

    /** Parse baris paste Durasi: "35" atau "35.918.4" → durasi / good / defect */
    const parseDurasiPasteLine = (line) => {
      const raw = String(line || '').trim();
      if (!raw) return null;

      const parts = raw.split(/[.\t,]/).map(s => s.trim());
      const durRaw = (parts[0] || '').replace(/[^\d]/g, '');
      const goodRaw = parts.length > 1 ? parts[1].replace(/[^\d]/g, '') : '';
      const defectRaw = parts.length > 2 ? parts[2].replace(/[^\d]/g, '') : '';

      if (durRaw === '') return null;
      const durNum = parseInt(durRaw, 10);
      if (!isFinite(durNum) || durNum < 0) return null;

      return {
        durasi: String(durNum),
        good: goodRaw !== '' ? goodRaw : null,
        defect: defectRaw !== '' ? defectRaw : null,
      };
    };

    const ensureRowsFrom = (startIdx, needCount) => {
      let all = Rows.rows();
      while (all.length < startIdx + needCount) {
        Rows.makeRow();
        all = Rows.rows();
      }
      Rows.updateRowNumbers();
      return all;
    };

    /** Setelah isi/kosongkan durasi: sinkron selesai baris ini + mulai baris berikutnya */
    const applyDurasiToSelesai = (row, durasiStr) => {
      const mulaiEl = row.querySelector('[data-f="mulai"]');
      const selesaiEl = row.querySelector('[data-f="selesai"]');
      const mulaiMin = mulaiEl ? Utils.parseTime(mulaiEl.value) : null;
      const raw = String(durasiStr ?? '').trim();
      const durMin = parseFloat(raw.replace(',', '.'));

      let next = row.nextElementSibling;
      while (next && !next.classList.contains('log-row')) next = next.nextElementSibling;
      const nextMulaiEl = next ? next.querySelector('[data-f="mulai"]') : null;

      if (raw === '' || !isFinite(durMin)) {
        if (selesaiEl) {
          selesaiEl.value = '';
          selesaiEl.classList.remove('invalid', 'warn-shift');
        }
        if (nextMulaiEl) {
          nextMulaiEl.value = '';
          nextMulaiEl.classList.remove('invalid', 'warn-shift');
        }
        return;
      }
      if (mulaiMin != null && durMin >= 0 && selesaiEl) {
        const endStr = Utils.minutesToHHMM(mulaiMin + durMin);
        selesaiEl.value = endStr;
        selesaiEl.classList.remove('invalid');
        Calculation.validateTimeInput(selesaiEl);
        if (nextMulaiEl) {
          nextMulaiEl.value = endStr;
          nextMulaiEl.classList.remove('invalid');
          Calculation.validateTimeInput(nextMulaiEl);
        }
      }
    };

    State.el.tbody.addEventListener('paste', (e) => {
      const t = e.target;
      if (!(t instanceof HTMLElement)) return;
      const field = t.getAttribute('data-f');
      if (field !== 'mulai' && field !== 'durasi') return;

      const cd = e.clipboardData || window.clipboardData;
      const text = cd ? (cd.getData('text') || '') : '';
      if (!text) return;

      const lines = text.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
      const isMulti = lines.length > 1;
      const isPacked = lines.length === 1 && /[.\t,]/.test(lines[0]);
      if (!isMulti && !isPacked) {
        // Satu nilai polos → biarkan paste default + handler input biasa
        return;
      }

      e.preventDefault();

      const startTr = t.closest('tr.log-row');
      if (!startTr) return;
      let allRows = Rows.rows();
      const startIdx = allRows.indexOf(startTr);
      if (startIdx < 0) return;

      // ---------- JAM MULAI ----------
      if (field === 'mulai') {
        const parsed = lines.map(parseMulaiPasteLine).filter(Boolean);
        if (!parsed.length) return;

        allRows = ensureRowsFrom(startIdx, parsed.length);
        let lastEl = t;

        parsed.forEach((item, offset) => {
          const row = allRows[startIdx + offset];
          if (!row) return;
          const mulaiEl = row.querySelector('[data-f="mulai"]');
          if (!mulaiEl) return;
          mulaiEl.value = item.mulai;
          mulaiEl.classList.remove('invalid');
          Calculation.validateTimeInput(mulaiEl);

          // Cascade: jam mulai baris ini → jam selesai baris sebelumnya
          const prevRow = offset === 0
            ? (() => {
                let prev = row.previousElementSibling;
                while (prev && !prev.classList.contains('log-row')) prev = prev.previousElementSibling;
                return prev;
              })()
            : allRows[startIdx + offset - 1];
          if (prevRow) {
            const sv = prevRow.querySelector('[data-f="selesai"]');
            if (sv) {
              sv.value = item.mulai;
              sv.classList.remove('invalid');
              Calculation.validateTimeInput(sv);
            }
          }

          if (item.good != null) {
            const goodEl = row.querySelector('[data-f="good"]');
            if (goodEl) goodEl.value = item.good;
          }
          if (item.defect != null) {
            const defectEl = row.querySelector('[data-f="defect"]');
            if (defectEl) defectEl.value = item.defect;
          }
          lastEl = mulaiEl;
        });

        Calculation.recalc();
        if (Rows.scrollRowIntoView) {
          const lastRow = lastEl.closest('tr.log-row');
          if (lastRow) Rows.scrollRowIntoView(lastRow, { behavior: 'smooth' });
        }
        try { lastEl.focus(); lastEl.select(); } catch (_) { /* ignore */ }
        if (typeof UI !== 'undefined' && UI.toast) {
          UI.toast(`Paste ${parsed.length} baris ke Jam Mulai ✓`);
        }
        return;
      }

      // ---------- DURASI ----------
      if (field === 'durasi') {
        const parsed = lines.map(parseDurasiPasteLine).filter(Boolean);
        if (!parsed.length) return;

        allRows = ensureRowsFrom(startIdx, parsed.length);
        let lastEl = t;

        parsed.forEach((item, offset) => {
          const row = allRows[startIdx + offset];
          if (!row) return;
          const durEl = row.querySelector('[data-f="durasi"]');
          if (!durEl) return;
          durEl.value = item.durasi;
          applyDurasiToSelesai(row, item.durasi);

          if (item.good != null) {
            const goodEl = row.querySelector('[data-f="good"]');
            if (goodEl) goodEl.value = item.good;
          }
          if (item.defect != null) {
            const defectEl = row.querySelector('[data-f="defect"]');
            if (defectEl) defectEl.value = item.defect;
          }
          lastEl = durEl;
        });

        Calculation.recalc();
        if (Rows.scrollRowIntoView) {
          const lastRow = lastEl.closest('tr.log-row');
          if (lastRow) Rows.scrollRowIntoView(lastRow, { behavior: 'smooth' });
        }
        try { lastEl.focus(); lastEl.select(); } catch (_) { /* ignore */ }
        if (typeof UI !== 'undefined' && UI.toast) {
          UI.toast(`Paste ${parsed.length} baris ke Durasi ✓`);
        }
      }
    });

    // ============================================================
    // SISIP / HAPUS BARIS (tombol ➕ & del)
    // ============================================================
    State.el.tbody.addEventListener('click', (e) => {
      const insertBtn = e.target.closest('.btn-insert');
      if (insertBtn) {
        const tr = insertBtn.closest('tr.log-row');
        if (tr && typeof Rows.insertRowAfter === 'function') {
          Rows.insertRowAfter(tr);
        }
        return;
      }

      const btn = e.target.closest('.del');
      if (!btn) return;
      const tr = btn.closest('tr');
      tr.classList.add('out');
      setTimeout(() => {
        tr.remove();
        Rows.updateRowNumbers();
        if (Rows.rows().length === 0) Rows.makeRow();
        Calculation.recalc();
      }, 190);
    });

    // ============================================================
    // MASTER PRODUK & OPERATOR → recalc + sync ke Master
    // ============================================================
    // Debounce kerja berat (rebuild dropdown / refresh WO semua baris / recalc)
    // supaya mengetik No. WO & kode produk di header tidak lag.
    const _prodTimers = {};
    const debounceProd = (key, fn, ms) => {
      clearTimeout(_prodTimers[key]);
      _prodTimers[key] = setTimeout(fn, ms);
    };
    ['prodName1','prodName2','prodName3','prodBn1','prodBn2','prodBn3','prodRate1','prodRate2','prodRate3','prodUkuran1','prodUkuran2','prodUkuran3','prodWo1','prodWo2','prodWo3'].forEach(id => {
      if (!State.el[id]) return;
      State.el[id].addEventListener('input', () => {
        // Sync ke Master Produk langsung (ringan)
        const masterEl = document.querySelector(`[data-sync="${id}"]`);
        if (masterEl && masterEl.value !== State.el[id].value) masterEl.value = State.el[id].value;

        const isNameBn = id.startsWith('prodName') || id.startsWith('prodBn');
        const isRateUk = id.startsWith('prodRate') || id.startsWith('prodUkuran');
        const isWo = id.startsWith('prodWo');

        // Header matrix teks bisa langsung (sangat ringan)
        if (isNameBn) Rows.updateMatrixProductHeaders();

        // Kerja berat: debounce 180ms; WO-only lebih agresif 120ms tanpa rebuild dropdown
        if (isWo) {
          debounceProd('wo', () => {
            if (Rows.refreshAllRowWo) Rows.refreshAllRowWo();
            else Rows.rows().forEach(tr => Rows.applyWoFromBatch(tr, { silent: true }));
          }, 120);
          return;
        }
        if (isNameBn || isRateUk) {
          debounceProd('prod', () => {
            Rows.updateAllDropdowns();
            if (isNameBn) Rows.updateMatrixProductHeaders();
            Calculation.recalc();
          }, 180);
        }
      });
      // Pastikan nilai final ikut terproses saat blur (tanpa menunggu debounce)
      State.el[id].addEventListener('change', () => {
        clearTimeout(_prodTimers['wo']);
        clearTimeout(_prodTimers['prod']);
        if (id.startsWith('prodName') || id.startsWith('prodBn') || id.startsWith('prodRate') || id.startsWith('prodUkuran')) {
          Rows.updateAllDropdowns();
          Rows.updateMatrixProductHeaders();
          Calculation.recalc();
        }
        if (id.startsWith('prodWo') || id.startsWith('prodName') || id.startsWith('prodBn')) {
          if (Rows.refreshAllRowWo) Rows.refreshAllRowWo();
          else Rows.rows().forEach(tr => Rows.applyWoFromBatch(tr, { silent: true }));
        }
      });
    });

    // ============================================================
    // SYNC DUA ARAH: Master Produk ↔ Sheet Produk
    // ============================================================
    document.querySelectorAll('#masterProductGrid [data-sync]').forEach(el => {
      const syncToSheet = () => {
        const targetId = el.getAttribute('data-sync');
        const target = State.el[targetId] || document.getElementById(targetId);
        if (!target) return;
        const val = el.value;
        if (target.value !== val) {
          target.value = val;
          target.dispatchEvent(new Event('input', { bubbles: true }));
          target.dispatchEvent(new Event('change', { bubbles: true }));
        }
      };
      el.addEventListener('input', syncToSheet);
      el.addEventListener('change', syncToSheet);
    });

    // ============================================================
    // FILTER CHANGES → reload
    // ============================================================
    ['fDate','fLine','fStage'].forEach(id => {
      State.el[id].addEventListener('change', Storage.loadRecord);
    });
    // Indikator Shift & Tanggal di toolbar atas ikut update tiap tanggal/tahapan diganti
    State.el.fDate.addEventListener('input', UI.updateShiftIndicator);
    State.el.fStage.addEventListener('change', () => { UI.updateShiftIndicator(); if (UI.applyStageUI) UI.applyStageUI(); });
    State.el.fLine.addEventListener('change', () => { UI.updateUnifiedControl(); if (UI.applyLineUI) UI.applyLineUI(); });
    if (UI.bindFilterToggles) UI.bindFilterToggles();

    // ============================================================
    // BUTTONS
    // ============================================================
    State.el.btnSave.addEventListener('click', () => Storage.saveData());
    State.el.btnReset.addEventListener('click', () => {
      if (!confirm('Reset seluruh form? Data yang belum disimpan akan hilang.')) return;
      Storage.applyRecord(null);
      UI.toast('Form dikosongkan ↺');
    });
    State.el.btnAdd.addEventListener('click', () => {
      const tr = Rows.makeRow();
      Rows.updateRowNumbers();
      if (Rows.markRowEnter) Rows.markRowEnter(tr);
      Calculation.recalc();
      if (Rows.scrollRowIntoView) Rows.scrollRowIntoView(tr, { behavior: 'smooth' });
      else tr.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      const cells = Navigation.navCells();
      const kodeCell = cells.find(c => c.f === 'kode' && c.ri === Rows.rows().length - 1);
      if (kodeCell) Navigation.focusCell(kodeCell);
    });
    // Export CSV log sheet aktif (sidebar + tombol di bawah tabel)
    const bindExportCsv = (el) => {
      if (el) el.addEventListener('click', () => Storage.exportCsv());
    };
    bindExportCsv(State.el.btnExportCsv);
    bindExportCsv(State.el.btnExportCsvSheet);

    // ============================================================
    // SALIN / PINDAH DATA
    // ============================================================
    const cmOverlay = document.getElementById('copyMoveOverlay');
    const cmOpen = () => {
      if (!cmOverlay) return;
      // Isi label sumber & default target = filter aktif
      const srcLabel = document.getElementById('cmSourceLabel');
      if (srcLabel) srcLabel.textContent = Storage.labelFilter();
      const f = Storage.activeFilter();
      const d = document.getElementById('cmTargetDate');
      const s = document.getElementById('cmTargetShift');
      const l = document.getElementById('cmTargetLine');
      const st = document.getElementById('cmTargetStage');
      if (d) d.value = f.rawDate;
      if (s) s.value = String(f.shift);
      if (l) l.value = String(f.line);
      if (st) st.value = f.stage;
      updateCmWarn();
      cmOverlay.classList.remove('hide');
    };
    const cmClose = () => {
      if (cmOverlay) cmOverlay.classList.add('hide');
    };
    const readTargetFilter = () => ({
      rawDate: document.getElementById('cmTargetDate')?.value || '',
      shift: Number(document.getElementById('cmTargetShift')?.value || 1),
      line: document.getElementById('cmTargetLine')?.value || '1',
      stage: document.getElementById('cmTargetStage')?.value || 'filling',
    });
    const updateCmWarn = () => {
      const warn = document.getElementById('cmWarn');
      if (!warn) return;
      const t = readTargetFilter();
      if (!t.rawDate) { warn.hidden = true; return; }
      warn.hidden = !Storage.targetExists(t);
    };
    ['cmTargetDate', 'cmTargetShift', 'cmTargetLine', 'cmTargetStage'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.addEventListener('change', updateCmWarn);
    });
    if (State.el.btnCopyMove) {
      State.el.btnCopyMove.addEventListener('click', cmOpen);
    }
    document.getElementById('copyMoveClose')?.addEventListener('click', cmClose);
    document.getElementById('copyMoveCancel')?.addEventListener('click', cmClose);
    cmOverlay?.addEventListener('click', (e) => {
      if (e.target === cmOverlay) cmClose();
    });
    document.getElementById('copyMoveConfirm')?.addEventListener('click', async () => {
      const target = readTargetFilter();
      if (!target.rawDate) {
        UI.toast('Pilih tanggal tujuan dulu', true);
        return;
      }
      const mode = document.querySelector('input[name="cmMode"]:checked')?.value || 'copy';
      const modeLabel = mode === 'move' ? 'pindahkan' : 'salin';
      if (!confirm(`Yakin ${modeLabel} data ke ${target.rawDate} · S${target.shift} · L${target.line} · ${target.stage.toUpperCase()}?`)) return;

      const btn = document.getElementById('copyMoveConfirm');
      if (btn) { btn.disabled = true; btn.textContent = 'Memproses…'; }
      try {
        const result = await Storage.copyOrMoveRecord(target, mode);
        if (!result.ok) {
          UI.toast(result.message, true);
          return;
        }
        UI.toast(result.message);
        cmClose();

        // Pindahkan filter UI ke tujuan, lalu load record tujuan
        if (State.el.fDate) State.el.fDate.value = target.rawDate;
        if (State.el.fLine) State.el.fLine.value = String(target.line);
        if (State.el.fStage) State.el.fStage.value = target.stage;
        State.evalShift = Number(target.shift) - 1;
        if (typeof UI.updateShiftIndicator === 'function') UI.updateShiftIndicator();
        if (typeof UI.updateUnifiedControl === 'function') UI.updateUnifiedControl();
        // Sync shift buttons
        document.querySelectorAll('[data-shift]').forEach(b => {
          b.classList.toggle('on', parseInt(b.getAttribute('data-shift'), 10) === State.evalShift);
        });
        await Storage.loadRecord();
        if (typeof Calculation !== 'undefined' && Calculation.recalc) Calculation.recalc();
      } catch (err) {
        console.error(err);
        UI.toast('Gagal salin/pindah: ' + (err.message || err), true);
      } finally {
        if (btn) { btn.disabled = false; btn.textContent = 'Jalankan'; }
      }
    });

    // ============================================================
    // Ctrl+S SHORTCUT
    // ============================================================
    window.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        Storage.saveData();
      }
    });
  };

  /**
   * Entry point global.
   */
  const bindLoginThemeToggle = () => {
    const buttons = document.querySelectorAll('[data-login-theme]');
    if (!buttons.length || typeof Settings === 'undefined') return;

    const sync = () => {
      const current = Settings.getLoginTheme();
      buttons.forEach(btn => {
        const active = btn.dataset.loginTheme === current;
        btn.classList.toggle('active', active);
        btn.setAttribute('aria-pressed', active ? 'true' : 'false');
      });
    };

    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        const theme = btn.dataset.loginTheme;
        Settings.setLoginTheme(theme);
        sync();
        if (typeof UI !== 'undefined' && UI.toast) {
          UI.toast(theme === 'professional' ? 'Tema login Profesional dipilih' : 'Tema login Santai dipilih');
        }
      });
    });

    sync();
  };

  /**
   * Toggle Tema Aplikasi (Standar / Profesional).
   * Hanya berlaku di mode terang. Saat gelap, tetap SuperGrok dark.
   * Preferensi Standar/Profesional disimpan di localStorage KEY terpisah
   * lewat Settings — saat kembali ke terang, style sebelumnya dipulihkan.
   */
  const KEY_STYLE = 'fima_app_style'; /* 'light' | 'professional' */

  const getAppStyle = () => {
    try { return localStorage.getItem(KEY_STYLE) || 'light'; } catch(e) { return 'light'; }
  };
  const setAppStyle = (style) => {
    try { localStorage.setItem(KEY_STYLE, style); } catch(e) {}
  };

  const bindAppThemeToggle = () => {
    const buttons = document.querySelectorAll('[data-app-theme]');
    if (!buttons.length || typeof Settings === 'undefined') return;

    const sync = () => {
      const style = getAppStyle();
      buttons.forEach(btn => {
        btn.classList.toggle('on', btn.dataset.appTheme === style);
      });
    };

    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        const style = btn.dataset.appTheme; // 'light' | 'professional'
        setAppStyle(style);
        // Hanya terapkan ke data-theme jika sedang mode terang
        if (Settings.getTheme() !== 'dark') {
          Settings.setTheme(style === 'professional' ? 'professional' : 'light');
        }
        sync();
        if (typeof UI !== 'undefined' && UI.toast) {
          UI.toast(style === 'professional' ? 'Tema aplikasi Profesional aktif' : 'Tema aplikasi Standar aktif');
        }
      });
    });

    sync();
  };

  /**
   * Mode Tampilan: Terang / Gelap (SuperGrok premium dark untuk sheet).
   */
  const bindColorModeToggle = () => {
    const buttons = document.querySelectorAll('[data-color-mode]');
    if (!buttons.length || typeof Settings === 'undefined') return;

    const sync = () => {
      const isDark = Settings.getTheme() === 'dark';
      buttons.forEach(btn => {
        const mode = btn.dataset.colorMode;
        btn.classList.toggle('on', isDark ? mode === 'dark' : mode === 'light');
      });
    };

    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        const mode = btn.dataset.colorMode; // 'light' | 'dark'
        if (mode === 'dark') {
          Settings.setTheme('dark');
        } else {
          // Kembali ke style terang yang terakhir dipilih (Standar/Profesional)
          const style = getAppStyle();
          Settings.setTheme(style === 'professional' ? 'professional' : 'light');
        }
        sync();
        // Sync icon topbar (jika ada tombol theme di shell)
        const themeBtn = document.getElementById('themeToggleBtn');
        if (themeBtn) {
          const dark = mode === 'dark';
          themeBtn.innerHTML = '<svg class="icon"><use href="./icons/sprite.svg#' + (dark ? 'i-sun' : 'i-moon') + '"></use></svg>';
        }
        if (typeof UI !== 'undefined' && UI.toast) {
          UI.toast(mode === 'dark' ? 'Mode gelap aktif' : 'Mode terang aktif');
        }
      });
    });

    sync();
  };

  const init = () => {
    State.initElements();
    bindLoginThemeToggle();
    bindAppThemeToggle();
    bindColorModeToggle();

    // Inisialisasi client Supabase (butuh CONFIG.SUPABASE_URL/ANON_KEY terisi benar)
    if (typeof SupabaseClient !== 'undefined') SupabaseClient.init();
    if (typeof Suggest !== 'undefined' && Suggest.initRemote) Suggest.initRemote();

    bindEvents();

    // Mode Input Cepat (Normal / Cepat 1 / Cepat 2) — additive, tidak
    // mengubah alur Mode Normal yang sudah ada.
    if (typeof QuickMode !== 'undefined') QuickMode.init();

    // Mode Form Input (kartu per-baris, additive — tabel tetap source of truth)
    if (typeof FormMode !== 'undefined') FormMode.init();
    if (typeof FormModeFull !== 'undefined') FormModeFull.init();

    // Isi Massal (kotak input daftar bernomor untuk kolom Kode / Jam Mulai)
    if (typeof BulkFill !== 'undefined') BulkFill.init();
    if (typeof PrintSheet !== 'undefined') PrintSheet.bind();
    if (typeof WhatsApp !== 'undefined') WhatsApp.bind();
    if (typeof PhotoImport !== 'undefined') PhotoImport.bind();
    if (typeof CsvImport !== 'undefined') CsvImport.bind();

    // Autocomplete kode produk di kolom Nama Produk (Sheet + Master)
    if (typeof Suggest !== 'undefined') {
      if (Suggest.seedHistoryFromDb) Suggest.seedHistoryFromDb();
      if (Suggest.attachProductAll) {
        Suggest.attachProductAll('#prodName1, #prodName2, #prodName3, #masterProdName1, #masterProdName2, #masterProdName3');
      }
    }

    Auth.initSession();

    // Coba kirim antrean offline yang tertunda (jika ada) begitu app siap
    if (typeof Sync !== 'undefined') Sync.flushQueue();
  };

  return { startMain, init };
})();

// Boot aplikasi saat DOM siap
document.addEventListener('DOMContentLoaded', App.init);

// ==========================================
// 1. PENGATURAN TAMBAH & HAPUS PRODUK CADANGAN
// ==========================================
function initProductButton() {
  const grid = document.getElementById('masterProductGrid');
  if (!grid) return;

  const prod1Box = grid.querySelector('div.field:nth-child(1)');
  const prod2Box = grid.querySelector('div.field:nth-child(2)');
  const prod3Box = grid.querySelector('div.field:nth-child(3)');
  const p2Name = document.getElementById('masterProdName2');
  const p3Name = document.getElementById('masterProdName3');

  // Buat tombol tambah produk
  let btnAdd = document.getElementById('btnTambahProduk');
  if (!btnAdd) {
    btnAdd = document.createElement('button');
    btnAdd.id = 'btnTambahProduk';
    btnAdd.type = 'button';
    btnAdd.className = 'btn-tambah-prod';
    btnAdd.textContent = '+ Tambah Produk Cadangan';
    grid.insertAdjacentElement('afterend', btnAdd);
  }

  // Kosongkan input master + mirror ke field sheet (prodName/Bn/Rate/…)
  function resetBox(box, hideAfter) {
    if (!box) return;
    box.querySelectorAll('input, select').forEach((el) => {
      el.value = '';
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      // Sinkron ke field sheet lewat data-sync
      const targetId = el.getAttribute('data-sync');
      if (targetId) {
        const target = (typeof State !== 'undefined' && State.el && State.el[targetId])
          || document.getElementById(targetId);
        if (target) {
          target.value = '';
          target.dispatchEvent(new Event('input', { bubbles: true }));
          target.dispatchEvent(new Event('change', { bubbles: true }));
        }
      }
    });
    if (hideAfter) box.classList.remove('show-prod');
    cekStatusTombol();
    // Paksa update kolom matrix OEE
    if (typeof window.syncOeeColumns === 'function') window.syncOeeColumns();
  }

  // Tombol hapus / bersihkan
  function pasangTombolHapus(box, labelText, hideAfter) {
    if (!box) return;
    // Pastikan field bisa memposisikan tombol absolut
    if (getComputedStyle(box).position === 'static') box.style.position = 'relative';
    let btnDel = box.querySelector('.btn-del-prod');
    if (!btnDel) {
      btnDel = document.createElement('button');
      btnDel.type = 'button';
      btnDel.className = 'btn-del-prod';
      box.appendChild(btnDel);
    }
    btnDel.innerHTML = hideAfter ? ('✕ Hapus ' + labelText) : ('✕ Bersihkan ' + labelText);
    btnDel.title = hideAfter
      ? ('Hapus dan sembunyikan ' + labelText)
      : ('Kosongkan data ' + labelText);
    btnDel.onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      resetBox(box, !!hideAfter);
    };
  }

  // Produk 1: bisa dibersihkan (slot tetap tampil)
  pasangTombolHapus(prod1Box, 'Produk 1', false);
  // Produk 2 & 3: hapus + sembunyikan
  pasangTombolHapus(prod2Box, 'Produk 2', true);
  pasangTombolHapus(prod3Box, 'Produk 3', true);

  // Cek apakah ada data lama tersimpan
  if (p2Name && p2Name.value.trim() !== '' && prod2Box) prod2Box.classList.add('show-prod');
  if (p3Name && p3Name.value.trim() !== '' && prod3Box) prod3Box.classList.add('show-prod');

  function cekStatusTombol() {
    const isP2 = prod2Box && prod2Box.classList.contains('show-prod');
    const isP3 = prod3Box && prod3Box.classList.contains('show-prod');
    if (isP2 && isP3) btnAdd.style.display = 'none';
    else btnAdd.style.display = 'inline-flex';
  }

  btnAdd.onclick = function () {
    if (prod2Box && !prod2Box.classList.contains('show-prod')) {
      prod2Box.classList.add('show-prod');
      p2Name?.focus();
    } else if (prod3Box && !prod3Box.classList.contains('show-prod')) {
      prod3Box.classList.add('show-prod');
      p3Name?.focus();
    }
    cekStatusTombol();
  };

  cekStatusTombol();
}

// ==========================================
// 2. SINKRONISASI KOLOM TABEL OEE
// ==========================================
function initMatrixSync() {
  const $ = id => document.getElementById(id);
  const val = id => (($(id) || {}).value || '').trim();

  // Slot dianggap aktif bila nama / BN / rate terisi (di Master ATAU di form Sheet)
  const slotAktif = n =>
    !!(val('masterProdName' + n) || val('masterProdBn' + n) || val('masterProdRate' + n) ||
       val('prodName' + n) || val('prodBn' + n) || val('prodRate' + n));

  function syncColumns() {
    const aktif = { 1: true, 2: slotAktif(2), 3: slotAktif(3) };
    const colCount = 1 + (aktif[2] ? 1 : 0) + (aktif[3] ? 1 : 0);

    // Tampil/sembunyikan SEMUA sel produk n di semua baris (header + G..M)
    [1, 2, 3].forEach(n => {
      const disp = aktif[n] ? '' : 'none';
      const cells = [$('thProd' + n)];
      ['G','H','I','J','K','L','M'].forEach(L => {
        const sp = $('o' + L + n);
        cells.push(sp ? sp.closest('td') : null);
      });
      cells.forEach(c => { if (c) c.style.display = disp; });
    });

    // Baris A-F & OEE melebar sesuai jumlah kolom produk aktif
    ['oA','oB','oC','oD','oE','oF','oee'].forEach(id => {
      const el = $(id);
      const td = el && el.closest('td');
      if (td) td.colSpan = colCount;
    });
    document.querySelectorAll('.oee-matrix-tbl .sec-header td').forEach(td => td.colSpan = 2 + colCount);
  }

  window.syncOeeColumns = syncColumns;

  // Pantau semua input produk (master + sheet), bukan hanya nama produk 2/3
  const ids = [];
  [1, 2, 3].forEach(n => ['masterProdName','masterProdBn','masterProdRate','prodName','prodBn','prodRate']
    .forEach(p => ids.push(p + n)));
  ids.forEach(id => {
    const el = $(id);
    if (el) ['input', 'change'].forEach(ev => el.addEventListener(ev, syncColumns));
  });

  syncColumns();
}

// ==========================================
// 3. JALANKAN SEMUA FUNGSI SAAT HALAMAN SIAP
// ==========================================
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    initProductButton();
    initMatrixSync();
  });
} else {
  initProductButton();
  initMatrixSync();
}